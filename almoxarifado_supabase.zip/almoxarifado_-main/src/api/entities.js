import { supabase } from '@/lib/supabaseClient';

// Traduz o formato de ordenação usado nas páginas (ex: '-created_date', 'name')
// para o formato que o Supabase espera. As tabelas usam created_at/updated_at
// (padrão do Postgres/Supabase), então mapeamos os nomes antigos do Base44.
function parseSort(sort) {
  if (!sort) return null;
  const descending = sort.startsWith('-');
  let field = descending ? sort.slice(1) : sort;
  if (field === 'created_date') field = 'created_at';
  if (field === 'updated_date') field = 'updated_at';
  return { field, ascending: !descending };
}

// Cria um objeto com a mesma "forma" que base44.entities.<Nome> tinha,
// mas lendo/gravando na tabela correspondente do Supabase. Isso evita
// reescrever a lógica de cada página — só troca de onde os dados vêm.
function createEntity(table) {
  return {
    async list(sort, limit) {
      let query = supabase.from(table).select('*');
      const s = parseSort(sort);
      if (s) query = query.order(s.field, { ascending: s.ascending });
      if (limit) query = query.limit(limit);
      const { data, error } = await query;
      if (error) throw error;
      return data;
    },

    async filter(criteria = {}, sort, limit) {
      let query = supabase.from(table).select('*');
      Object.entries(criteria).forEach(([key, value]) => {
        query = query.eq(key, value);
      });
      const s = parseSort(sort);
      if (s) query = query.order(s.field, { ascending: s.ascending });
      if (limit) query = query.limit(limit);
      const { data, error } = await query;
      if (error) throw error;
      return data;
    },

    async get(id) {
      const { data, error } = await supabase.from(table).select('*').eq('id', id).single();
      if (error) throw error;
      return data;
    },

    async create(payload) {
      const { data, error } = await supabase.from(table).insert([payload]).select();
      if (error) throw error;
      return data[0];
    },

    async bulkCreate(rows) {
      const { data, error } = await supabase.from(table).insert(rows).select();
      if (error) throw error;
      return data;
    },

    async update(id, payload) {
      const { data, error } = await supabase.from(table).update(payload).eq('id', id).select();
      if (error) throw error;
      return data[0];
    },

    async delete(id) {
      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) throw error;
      return true;
    },
  };
}

export const Item = createEntity('items');
export const Employee = createEntity('employees');
export const StockMovement = createEntity('stock_movements');
export const PurchaseRequest = createEntity('purchase_requests');
export const UserPermission = createEntity('user_permissions');
